?package(amxa-client-media):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="amxa-client-media" command="/usr/bin/amxa-client-media"
