# Defaults for amxa-client-media initscript
# sourced by /etc/init.d/amxa-client-media
# installed at /etc/default/amxa-client-media by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
